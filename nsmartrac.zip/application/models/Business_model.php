<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Business_model extends MY_Model {



	public $table = 'business_profile';	
	public function __construct()
	{
		parent::__construct();
	}

	
}



/* End of file Business_model.php */

/* Location: ./application/models/Business_model.php */