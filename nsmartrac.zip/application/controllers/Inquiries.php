<?php
defined('BASEPATH') OR exit('No direct script access allowed');

include_once 'application/services/CustomerSource.php';

class Inquiries extends MY_Controller {

    public function __construct()
    {
        parent::__construct();

        $this->page_data['page']->title = 'My Customers';
        $this->page_data['page']->menu = 'customers';
        $this->load->model('Inquiry_model', 'inquiry_model');

        $this->checkLogin();

        $this->load->library('session');
        $user_id = getLoggedUserID();

        // concept

        $uid = $this->session->userdata('uid');

        if (empty($uid)) {
            $this->page_data['uid'] = md5(time());
            $this->session->set_userdata(['uid' => $this->page_data['uid']]);
        } else {
            $uid = $this->session->userdata('uid');
            $this->page_data['uid'] = $uid;
        }

        // CSS to add only Customer module

        add_css(array(
            'assets/css/jquery.signaturepad.css',
            'https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css',
            'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css',
            'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css',
            'https://cdn.datatables.net/select/1.3.1/css/select.dataTables.min.css',
            'assets/frontend/css/invoice/main.css'
        ));

        // JS to add only Customer module
        add_footer_js(array(
            'assets/frontend/js/creditcard.js',
            'assets/frontend/js/inquiry/add.js',
            'assets/js/invoice.js'
            'https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js',
            'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js',
            'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js',
            'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js',
            'https://cdn.datatables.net/select/1.3.1/js/dataTables.select.min.js',
        ));

    }
	
	public function index($status_index = 0)
    {
        $role = logged('role');

        if ($role == 2 || $role == 3) {

            $comp_id = logged('comp_id');

            if (!empty($status_index)) {

                $this->page_data['tab_index'] = $status_index;
                $this->page_data['inquiries'] = $this->inquiry_model->filterBy(array('status' => $status_index), $comp_id);
            } else {

                if (!empty(get('search'))) {

                    $this->page_data['search'] = get('search');
                    $this->page_data['inquiries'] = $this->inquiry_model->filterBy(array('search' => get('search')), $comp_id);
                } elseif (!empty(get('type'))) {

                    $this->page_data['type'] = get('type');

                    if (!empty(get('order'))) {
                        $this->page_data['order'] = get('order');
                        $this->page_data['inquiries'] = $this->inquiry_model->filterBy(array('type' => get('type', 'order'), 'order' => get('order')), $comp_id);
                    } else {
                        $this->page_data['inquiries'] = $this->inquiry_model->filterBy(array('type' => get('type')), $comp_id);
                    }
                } else {

                    if (!empty(get('order'))) {
                        $this->page_data['order'] = get('order');
                        $this->page_data['inquiries'] = $this->inquiry_model->filterBy(array('type' => get('type', 'order'), 'order' => get('order')), $comp_id);
                    } else {
//                        $this->page_data['inquiries'] = $this->inquiry_model->filterBy(array('type' => get('type')), $comp_id);
                        $this->page_data['inquiries'] = $this->inquiry_model->getAllByCompany($comp_id);
                    }

//                    $this->page_data['inquiries'] = $this->inquiry_model->getAllByCompany($comp_id);
                }
            }

            $this->page_data['statusCount'] = $this->inquiry_model->getStatusWithCount($comp_id);

        }

        if ($role == 4) {

            if (!empty($status_index)) {

                $this->page_data['tab_index'] = $status_index;
                $this->page_data['inquiries'] = $this->inquiry_model->filterBy(array('status' => $status_index));
            } else {

                if (!empty(get('search'))) {

                    $this->page_data['search'] = get('search');
                    $this->page_data['inquiries'] = $this->inquiry_model->filterBy(array('search' => get('search')));
                } elseif (!empty(get('type'))) {

                    $this->page_data['type'] = get('type');

                    if (!empty(get('order'))) {
                        $this->page_data['order'] = get('order');
                        $this->page_data['inquiries'] = $this->inquiry_model->filterBy(array('type' => get('type', 'order'), 'order' => get('order')));
                    } else {
                        $this->page_data['inquiries'] = $this->inquiry_model->filterBy(array('type' => get('type')));
                    }
                } else {

                    if (!empty(get('order'))) {
                        $this->page_data['order'] = get('order');
                        $this->page_data['inquiries'] = $this->inquiry_model->filterBy(array('type' => get('type', 'order'), 'order' => get('order')));
                    } else {
//                        $this->page_data['inquiries'] = $this->inquiry_model->filterBy(array('type' => get('type')));
                        $this->page_data['inquiries'] = $this->inquiry_model->getAllByUserId();
                    }

//                    $this->page_data['inquiries'] = $this->inquiry_model->getAllByUserId();
                }
            }

            $this->page_data['statusCount'] = $this->inquiry_model->getStatusWithCount();
        }

//        print_r($this->page_data['statusCount']); die;
        $this->load->view('inquiry/inquiries', $this->page_data);
    }

	public function add()
    {
        $user_id = logged('id');
        $parent_id = $this->db->query("select parent_id from users where id=$user_id")->row();

        if ($parent_id->parent_id == 1) { // ****** if user is company ******//
            $this->page_data['users'] = $this->users_model->getAllUsersByCompany($user_id);
        } else {
            $this->page_data['users'] = $this->users_model->getAllUsersByCompany($parent_id->parent_id, $user_id);
        }
        //
        $comp_id = logged('comp_id');
        $this->page_data['workstatus'] = $this->Workstatus_model->getByWhere(['comp_id' => $comp_id]);
        $this->page_data['plans'] = $this->plans_model->getByWhere(['comp_id' => $comp_id]);
		
        $this->load->view('inquiry/add', $this->page_data);
	}
	
	public function edit($id)

    {


        $comp_id = logged('comp_id');

        $user_id = logged('id');

        $parent_id = $this->db->query("select parent_id from users where id=$user_id")->row();


        $this->load->model('Users_model', 'users_model');


        if ($parent_id->parent_id == 1) {

            $this->page_data['users'] = $this->users_model->getAllUsersByCompany($user_id);

        } else {

            $this->page_data['users'] = $this->users_model->getAllUsersByCompany($parent_id->parent_id, $user_id);

        }

        $this->page_data['inquiry'] = $this->inquiry_model->getByWhere(['company_id' => $comp_id]);

        $this->page_data['inquiry'] = $this->inquiry_model->getById($id);

        $this->page_data['inquiry']->service_address = unserialize($this->page_data['inquiry']->service_address);

        $this->page_data['inquiry']->additional_contacts = unserialize($this->page_data['inquiry']->additional_contacts);

        $this->page_data['inquiry']->additional_info = unserialize($this->page_data['inquiry']->additional_info);

        $this->page_data['inquiry']->card_info = unserialize($this->page_data['inquiry']->card_info);

        if (is_serialized($this->page_data['inquiry']->phone)) {
            $this->page_data['inquiry']->phone = unserialize($this->page_data['inquiry']->phone)['number'];
        }

        $this->load->model('Source_model', 'source_model');

        $this->page_data['inquiry']->source = $this->source_model->getSource($this->page_data['inquiry']->source_id);


        $this->load->view('inquiry/edit', $this->page_data);

    }


    public function save()
    {
        $user = (object)$this->session->userdata('logged');

        $comp_id = logged('comp_id');


//         echo '<pre>'; print_r($this->input->post()); die;


        $data = array(
            'inquiry_type' => post('inquiry_type'),
            'contact_name' => post('contact_name'),
            'contact_email' => post('contact_email'),
            'phone' => post('contact_phone'),
            'notification_method' => post('notify_by'),
            'street_address' => post('street_address'),
            'suite_unit' => post('suite_unit'),
            'city	' => post('city'),
            'postal_code' => post('zip'),
            'state' => post('state'),
            'source_id' => post('inquiry_source_id'),
            'comments' => post('notes'),
            'user_id' => $user->id,
            'company_id' => $comp_id
        );


        // previously generated inquiry id

        // this id will be present on session if addition contact or service address has been added

        $cid = $this->session->userdata('inquiry_id');


        // if no addition contact or service address has been added

        // create() will be called insted of update()

        if (!empty($cid)) {


            $id = $this->inquiry_model->update($cid, $data);

        } else {


            $id = $this->inquiry_model->create($data);

        }


        $this->activity_model->add("User #$user->id Updated by User:" . logged('name'));

        $this->session->set_flashdata('alert-type', 'success');

        $this->session->set_flashdata('alert', 'New inquiry Created Successfully');


        // clear sessions

        $this->session->unset_userdata('uid');

        $this->session->unset_userdata('inquiry_id');


        die(json_encode(

            array(

                'url' => base_url('inquiries')

            )

        ));

    }


    public function update($id)

    {

        $user = (object)$this->session->userdata('logged');

        $comp_id = logged('comp_id');


        // echo '<pre>'; print_r($this->input->post()); die;


        $data = array(


            'inquiry_type' => post('inquiry_type'),

            'contact_name' => post('contact_name'),

            'contact_email' => post('contact_email'),

            'mobile' => post('contact_mobile'),

            'phone' => post('contact_phone'),

            'notification_method' => post('notify_by'),

            'street_address' => post('street_address'),

            'suite_unit' => post('suite_unit'),

            'city	' => post('city'),

            'postal_code' => post('zip'),

            'state' => post('state'),

            'birthday' => date('Y-m-d', strtotime(post('birthday'))),

            'source_id' => post('inquiry_source_id'),

            'comments' => post('notes'),

            'user_id' => $user->id,

            'additional_info' => (!empty(post('additional'))) ? serialize(post('additional')) : NULL,

            'card_info' => (!empty(post('card'))) ? serialize(post('card')) : NULL,

            'company_id' => $comp_id
        );


        $id = $this->inquiry_model->update($id, $data);


        $this->activity_model->add("User #$user->id Updated by User:" . logged('name'));

        $this->session->set_flashdata('alert-type', 'success');

        $this->session->set_flashdata('alert', 'Inquiry has been Updated Successfully');


        die(json_encode(

            array(

                'url' => base_url('inquiry')

            )

        ));

    }


    public function service_address_form()

    {


        $get = $this->input->get();


        if (!empty($get)) {


            $this->page_data['action'] = $get['action'];

            $this->page_data['data_index'] = $get['index'];

            $this->page_data['inquiry'] = $this->inquiry_model->getInquiry($get['inquiry_id']);

            $this->page_data['service_address'] = $this->inquiry_model->getServiceAddress(array('id' => $get['inquiry_id']), $get['index']);

            // print_r($this->page_data['service_address']); die;

        }

    }


    public function save_service_address()

    {


        $post = $this->input->post();


        // save service address to db

        if (!empty($post['inquiry_id'])) {

            $cid = $post['inquiry_id'];

        } else {

            $cid = $this->session->userdata('inquiry_id');

        }


        if (empty($cid))

            $inquiry_id = $this->inquiry_model->saveServiceAddress($post);

        else {

            $this->inquiry_model->saveServiceAddress($post, $cid);

        }


        if (empty($cid)) {

            $this->session->set_userdata(['inquiry_id' => $inquiry_id]);

        } else {

            $inquiry_id = $cid;

        }


        die(json_encode(

            array(

                'inquiry_id' => $inquiry_id

            )

        ));

    }


    public function json_get_address_services()

    {


        $get = $this->input->get();


        if (!empty($get['inquiry_id'])) {

            $cid = $get['inquiry_id'];

        } else {

            $cid = $this->session->userdata('inquiry_id');

        }


        if (!empty($cid)) {


            $this->page_data['inquiry_id'] = $cid;

            $this->page_data['serviceAddresses'] = $this->inquiry_model->getServiceAddress(array('id' => $cid));

            // echo '<pre>'; print_r($serviceAddresses); die;

        }


        die($this->load->view('inquiry/service_address_list', $this->page_data, true));

    }


    public function json_get_additional_contacts()

    {

        $get = $this->input->get();


        if (!empty($get['inquiry_id'])) {

            $cid = $get['inquiry_id'];

        } else {

            $cid = $this->session->userdata('inquiry_id');

        }


        if (!empty($cid)) {


            $this->page_data['inquiry_id'] = $cid;

            $this->page_data['additionalContacts'] = $this->inquiry_model->getAdditionalContacts(array('id' => $cid));

            // echo '<pre>'; print_r($serviceAddresses); die;

        }


        die($this->load->view('inquiry/additional_contact_list', $this->page_data, true));

    }


    public function save_additional_contact()

    {


        $post = $this->input->post();


        // clear sessions

        // $this->session->unset_userdata('uid');

        // $this->session->unset_userdata('inquiry_id');


        // save service address to db

        if (!empty($post['inquiry_id'])) {

            $cid = $post['inquiry_id'];

        } else {

            $cid = $this->session->userdata('inquiry_id');

        }


        if (empty($cid))

            $inquiry_id = $this->inquiry_model->saveAdditionalContact($post);

        else {

            $this->inquiry_model->saveAdditionalContact($post, $cid);

        }


        if (empty($cid)) {

            $this->session->set_userdata(['inquiry_id' => $inquiry_id]);

        } else {

            $inquiry_id = $cid;

        }


        die(json_encode(

            array(

                'inquiry_id' => $inquiry_id

            )

        ));

    }


    public function remove_additional_contact()

    {


        $post = $this->input->post();


        if ($this->inquiry_model->removeAdditionalContact($post['inquiry_id'], $post['index'])) {


            die(json_encode(

                array(

                    'status' => 'success'

                )

            ));

        } else {


            die(json_encode(

                array(

                    'status' => 'error'

                )

            ));

        }

    }


    public function json_dropdown_inquiry_list()
    {


        $get = $this->input->get();

        $role = logged('role');

        if ($role == 2 || $role == 3) {

            $comp_id = logged('comp_id');

            $this->page_data['inquiries'] = $this->inquiry_model->getAllByCompany($comp_id, $get);

        }

        if ($role == 4) {

            $this->page_data['inquiries'] = $this->inquiry_model->getAllByUserId('', '', 0, 0, $get);

        }


        die(json_encode($this->page_data['inquiries']));

    }


    public function tab($index)
    {

        $this->index($index);
    }


    /**
     * @param $id
     */
    public function delete($id)

    {

        if ($id !== 1 && $id != logged($id)) {
        } else {

            redirect('/', 'refresh');

            return;
        }


        $id = $this->inquiry_model->delete($id);


        $this->activity_model->add("inquiry #$id Deleted by User:" . logged('name'));


        $this->session->set_flashdata('alert-type', 'success');

        $this->session->set_flashdata('alert', 'inquiry has been Deleted Successfully');


        redirect('inquiries');
    }

        /**
     *
     */
    public function source()
    {
        // pass the $this so that we can use it to load view, model, library or helper classes
        $customerSource = new CustomerSource($this);
    }
}

/* End of file Inquiries.php */
/* Location: ./application/controllers/Inquiries.php */
