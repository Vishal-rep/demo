<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Report extends MY_Controller {



	public function __construct()

	{
		parent::__construct();

		$this->page_data['page']->title = 'Report';

		$this->page_data['page']->menu = 'report';	
		$this->load->model('Estimate_model', 'estimate_model');
		$this->load->model('Invoice_model', 'invoice_model');

        $user_id = getLoggedUserID();
        
                // add css and js file path so that they can be attached on this page dynamically
        // add_css and add_footer_js are the helper function defined in the helpers/basic_helper.php
        add_css(array(
            'https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css',
            'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css',
            'https://cdn.datatables.net/select/1.3.1/css/select.dataTables.min.css',
            'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css',
            'assets/frontend/css/report/main.css',
        ));


        // JS to add only Customer module
        add_footer_js(array(
            'https://cdn.jsdelivr.net/jquery/latest/jquery.min.js',
            'https://cdn.jsdelivr.net/momentjs/latest/moment.min.js',
            'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js',
            'assets/frontend/js/report/main.js'
        ));
	}

	public function workorder()
	{

        $this->getUsers();      
        $this->page_data['workorders'] = $this->workorder_model->getAllByUserId();           
   		$this->load->view('report/workorder/view', $this->page_data);

    }

    public function main()
	{
        $this->getUsers();      
   		$this->load->view('report/main/main', $this->page_data);

    }

    public function monthly_closeout()
	{
        $format = $this->input->get('format');

        if ($format === "pdf") {
            $img = explode("/", parse_url((companyProfileImage(logged('comp_id'))) ? companyProfileImage(logged('comp_id')) : $url->assets)['path']);
            $this->page_data['profile'] = $img[2] . "/" . $img[3] . "/" . $img[4];
            $filename = "monthly_closeout_".date("Ymd");
            $this->load->library('pdf');
            $this->pdf->load_view('report/main/pdf/template', $this->page_data, $filename);
        } else if ($format === "csv") {
            $this->workorder_to_csv();
        } else {
            $this->getUsers();    
            $comp_id = logged('comp_id');  
            $this->page_data['estimates'] = $this->estimate_model->getAllByCompany($comp_id);           
            $this->page_data['invoices'] = $this->invoice_model->getAllByCompany($comp_id, 0);           
            $this->load->view('report/main/montly_closeout', $this->page_data);
        }
    }

    public function getUsers() {

        $user_id =  logged('id');
        $parent_id = $this->db->query("select parent_id from users where id=$user_id")->row();	
        
        if($parent_id->parent_id == 1) { // ****** if user is company ******//

            $this->page_data['users'] = $this->users_model->getAllUsersByCompany($user_id);
        
        } else {			
        
            $this->page_data['users'] = $this->users_model->getAllUsersByCompany($parent_id->parent_id, $user_id);			
        }       

    }

    public function filterReports() {
        $data = $this->input->post();
        return $data;
    }

    public function searchByKeyword($type='', $status='', $emp_id=0) {

        $this->getUsers();

       // echo $this->uri->segment(5);die;
        $this->page_data['workorders'] = $this->workorder_model->getAllByUserId($type, $status, $emp_id);           
        $this->load->view('report/workorder/view', $this->page_data);
    }

    public function workorder_to_csv()
    {
       
       $data = $this->input->post();       
      
        $delimiter = ",";
        $filename = 'workorder';
        $filename = $filename.date('Ymd').time(). ".csv";

        //create a file pointer
        $f = fopen('php://memory', 'w');

        //set column headers->fullname,1);
                        
        $fields = array('Workorder#', 'Custome Name', 'Type', 'WO Status', 'Assigned To', 'Date Issued', 'Total Price', 'Expenses', 'Profit');
        fputcsv($f, $fields, $delimiter);

        //output each row of the data, format line as csv and write to file pointer
        //echo "<pre>";print_r($all);die;
     
        if(!empty($data)){           

            for($i=0; $i<count($data['workorder_id']); $i++) {

                $csvData       = array($data['workorder_id'][$i], $data['contact_name'][$i], $data['customer_type'][$i], $data['workorder_status'][$i], $data['assign_to'][$i], $data['workorder_date'][$i], $data['workorder_price'][$i], '$0.00', '$0.00');
                fputcsv($f, $csvData, $delimiter);
            }
            // foreach($data as $row){              
             
            //     $csvData       = array('WO-00'.$row->workorder_id, $row->workorder_date, $row->contact_name, '$'.$row->contact_name->total_price, '$0.00', '$0.00');
            //     fputcsv($f, $csvData, $delimiter);
            // }
        }
        else
        {
            $csvData = array('');
            fputcsv($f, $csvData, $delimiter);
        }

        fseek($f, 0);

        //set headers to download file rather than displayed
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '";');

        //output all remaining data on a file pointer
        fpassthru($f);
    }


}



/* End of file Comapny.php */

/* Location: ./application/controllers/Users.php */