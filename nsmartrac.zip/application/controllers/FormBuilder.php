<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class FormBuilder extends MY_Controller {

	public function __construct()
	{

		parent::__construct();
		// $this->page_data['page']->title = 'Form Builder';
		// $this->page_data['page']->menu = 'Builder';
		// $user_id = getLoggedUserID();

		// if($user_id != 1) { redirect('/'); }
	}

	public function index()
	{
		$this->load->view('formbuilder/add', $this->page_data);
	}


}