<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Survey_model extends MY_Model {


	public function __construct()
	{
		parent::__construct();
	}

	public function add($data)
	{
    $this->db->insert('survey', $data);
		$insert_id = $this->db->insert_id();

		$this->db->select('*');
		$this->db->where('id', $insert_id);
		$query = $this->db->get('survey');
		return $query->row();
	}

	public function delete($id){
		$this->db->where('id', $id);
		return $this->db->delete('survey');
	}

  public function list(){
    $this->db->select('*');
    $query = $this->db->get('survey');
    return $query->result();
  }

  public function view($id){
    $this->db->select('*');
    $this->db->where('id', $id);
    $query = $this->db->get('survey');

    return $query->row();
  }

  public function addQuestion($id, $tid){

    $this->db->select('*');
    $this->db->where('id', $tid);
    $query = $this->db->get('survey_template_questions');
    $template = $query->row();

		$data = array(
      'survey_id' => $id,
      'question' => $template->question,
      'template_id' => $tid
    );

		$this->db->insert('survey_questions', $data);
		$insert_id = $this->db->insert_id();

		$data_option = array(
			'survey_template_choice' => $template->answer,
			'survey_template_id' => $insert_id,
		);
		$this->db->insert('survey_template_answer', $data_option);
		$tinsert_id = $this->db->insert_id();

		if($tid == 4){
			$test = '<div class="input-group mb-3">
					<div class="input-group-prepend">
						<div class="input-group-text">
							<input type="checkbox" aria-label="Checkbox for following text input">
						</div>
					</div>
					<input name="choices_label_'.$tinsert_id.'" type="text" class="form-control"  value="">
				</div>';
		}elseif($tid == 3) {
			$test = '<div class="input-group mb-2">
					 <div class="input-group-prepend">
						<div class="input-group-text">
						<input name="options" type="radio" aria-label="Radio button for following text input">
						</div>
					</div>
					<input name="choices_label_'.$tinsert_id.'" type="text" class="form-control">
				</div>';
		}else{
			$test = '';
		}

		$data = array(
			'id'=> $insert_id,
			'tid' => $tid,
			'data' => $template->answer,
			'test' => $test,
			'question' => $template->question,
			'template_title' => $template->type
		);
    return $data;
  }

  public function getQuestions($id){
    $this->db->select('*');
    $this->db->where('survey_id', $id);
		$this->db->order_by('order', 'ASC');
    $query = $this->db->get('survey_questions');

		$check = array_map( function($data){
			$this->db->select('*');
			$this->db->where('survey_template_id', $data->id);
			$query = $this->db->get('survey_template_answer');
			$data->questions = $query->result();

			$this->db->select('*');
			$this->db->where('id', $data->template_id);
			$template = $this->db->get('survey_template_questions');

			$data->template_title = $template->row()->type;
				if($data->template_id == 3){
				foreach ($data->questions as $key => $value) {
					$token = array_map(function($data){
						$test = '<div class="input-group mb-2">
                         <div class="input-group-prepend">
                          <div class="input-group-text">
                          <input name="options" type="radio" aria-label="Radio button for following text input">
                          </div>
                        </div>
                        <input name="choices_label_'.$data->id.'" type="text" class="form-control" value="'.$data->choices_label.'">
                      </div>';
						$data->questions = "";
						$data->survey_template_choice = $test;
						return $data;
					},$data->questions);

				}
			}elseif($data->template_id == 4){
				$token = array_map(function($data){
					$test = '<div class="input-group mb-3">
					    <div class="input-group-prepend">
					      <div class="input-group-text">
					        <input type="checkbox" aria-label="Checkbox for following text input">
					      </div>
					    </div>
					    <input name="choices_label_'.$data->id.'" type="text" class="form-control"  value="'.$data->choices_label.'">
					  </div>';
					$data->questions = "";
					$data->survey_template_choice = $test;
					return $data;
				},$data->questions);
			}
			return $data;
		}, $query->result());

    return $check;
  }
  public function getQuestionsPreview($id){
    $this->db->select('*');
    $this->db->where('survey_id', $id);
		$this->db->order_by('order', 'ASC');
    $query = $this->db->get('survey_questions');

		$check = array_map( function($data){
			$this->db->select('*');
			$this->db->where('survey_template_id', $data->id);
			$query = $this->db->get('survey_template_answer');
			$data->questions = $query->result();

			$this->db->select('*');
			$this->db->where('id', $data->template_id);
			$template = $this->db->get('survey_template_questions');

			$data->template_title = $template->row()->type;
				if($data->template_id == 3){
				foreach ($data->questions as $key => $value) {
					$token = array_map(function($data){
						$test = '<div class="form-check">
			          <input name="answer" value="'. $data->choices_label .'" class="form-check-input" type="radio" id="gridRadios'. $data->id .'">
			          <label class="form-check-label" for="gridRadios'. $data->id .'">
			            '.$data->choices_label.'
			          </label>
			        </div>';
						$data->questions = "";
						$data->survey_template_choice = $test;
						return $data;
					},$data->questions);

				}
			}elseif($data->template_id == 4){
				$token = array_map(function($data){
						$test = '<div class="form-check">
						<input name="answer" value="'. $data->choices_label .'" class="form-check-input" type="checkbox" id="gridCheck'. $data->id .'">
						<label class="form-check-label" for="gridCheck'.  $data->id  .'">
						'.$data->choices_label.'
						</label>
					</div>';
					$data->questions = "";
					$data->survey_template_choice = $test;
					return $data;
				},$data->questions);
			}
			return $data;
		}, $query->result());

    return $check;
  }

  public function updateQuestion($id, $data, $all_data){
		$this->db->select('*');
		$this->db->where('id', $all_data['survey_id']);
		$survey = $this->db->get('survey_questions');

		if($survey->row()->template_id == 4 || $survey->row()->template_id == 3){
			$this->db->select('*');
			$this->db->where('survey_template_id', $all_data['survey_id']);
			$templates = $this->db->get('survey_template_answer');
			foreach ($templates->result() as $template) {
				$ids = $template->id;
				$datas = array(
					'choices_label' => $_POST['choices_label_'.$ids.'']
				);
				$this->db->where('id', $ids);
				$this->db->update('survey_template_answer', $datas);
			}
		}

    $this->db->where('id', $id);
    return $this->db->update('survey_questions', $data);
  }

	public function deleteQuestion($id){
		$this->db->where('id', $id);
		return $this->db->delete('survey_questions');
	}

	public function addQuestionChoice($id, $tid){
		$this->db->where('id', $tid);
		$query1 = $this->db->get('survey_template_questions');

		$update_data = array(
			'survey_template_id' => $id,
			'survey_template_choice' => $query1->row()->answer
		);
		$query = $this->db->insert('survey_template_answer', $update_data);
		$insert_id = $this->db->insert_id();
		if($tid == 4){
			$test = '<div class="input-group mb-3">
					<div class="input-group-prepend">
						<div class="input-group-text">
							<input type="checkbox" aria-label="Checkbox for following text input">
						</div>
					</div>
					<input name="choices_label_'.$insert_id.'" type="text" class="form-control"  value="">
				</div>';
		}else {
			$test = '<div class="input-group mb-2">
					 <div class="input-group-prepend">
						<div class="input-group-text">
						<input name="options" type="radio" aria-label="Radio button for following text input">
						</div>
					</div>
					<input name="choices_label_'.$insert_id.'" type="text" class="form-control">
				</div>';
		}

		return $test;
	}

	public function orderUpdate($data){
		foreach($data as $key => $id){
			$data = array(
				'order' => $key
			);
			$this->db->where('id', $id);
			$this->db->update('survey_questions', $data);
		}
		return TRUE;
	}

	public function addQuestionSettings($data, $id){
		$this->db->where('id', $id);
		return $this->db->update('survey_questions', $data);
	}
}
